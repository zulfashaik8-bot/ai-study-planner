# AI Study Planner — StudyMate

A responsive student study-planning web application built with HTML, CSS, and JavaScript.

## Features
- Add tasks with subject, study date, duration, and priority
- Mark tasks complete or pending
- Filter by date and completion status
- Track today's task completion progress
- Rule-based AI-style study suggestions (no API key required)
- Light/dark theme
- Stores tasks in browser local storage

## Run locally
1. Download and extract the ZIP file.
2. Open `index.html` in a modern browser.
3. Tasks are saved in that browser's local storage.

## Publish using GitHub Pages
1. Create a public repository named `ai-study-planner`.
2. Upload `index.html`, `style.css`, `script.js`, and `README.md` to the repository root.
3. Go to **Settings → Pages**.
4. Select **Deploy from a branch**, choose `main` and `/ (root)`, then save.
5. Your deployed URL will typically be `https://YOUR-USERNAME.github.io/ai-study-planner/`.

## Note
The “AI-style” study coach uses simple local rules and does not call an external AI model. Data is stored in the current browser and does not sync between devices.
